Pok�mon Duodecuple Distribution v1.4 by Prof. 9

Features:
- Multiple Wonder Cards in a single distro ROM
- Ignores date restrictions
- Automatically fixes Wonder Card checksums

How to generate a 12-distro ROM:
1. Put a clean Liberty Ticket distro ROM in the tools folder, name it wnw-y8kp.nds
2. In the tools folder, edit 12distro.asm and background.bmp to fit your needs
3. Fire up 12distro.bat and use option 1 to create a base 12-distro ROM
4. Extract Wonder Cards from other distro ROMs using option 2
5. Place all the Wonder Cards you want in the cards folder, name them XX.bin
6. Use option 3 to compile a 12-distro ROM with the cards you want

Credits/Thanks:
- Kingcom (ARMIPS)
- DarkFader (ndstool)
- cearn (grit)
- Yellow Wood Goblin (slot-1 read fix)